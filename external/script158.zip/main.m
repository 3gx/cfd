    lamda = spectrum(spectrum_type,N);
    [h,poly_coeff]=opt_poly_bisect(lamda,s,p,basis_type);
    disp('Optimal step size: ')
    disp(h)
    disp('Polynomial coefficients: ')
    disp(poly_coeff)
    plotstabreg_func(poly_coeff)
    
